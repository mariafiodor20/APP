#define BLOCK_SIZE 32	
#define CRY_MAGIC 0xC470A712
#define MAX_FILE_NAME 256

#define MAJOR_VER 0
#define MINOR_VER 1
#define RELEASE_VER 0

/*options for command line*/
enum option_arg_types {
    NEXT_OPT_KEYFILE, 
    NEXT_OPT_PASSWORD  
};


typedef struct header
{
    ulong magic;
    ushort major;
    ushort minor;
    ulong file_len;
    ulong enc_type;
    ulong crc;
} header;

#define FALSE 0
#define TRUE 1

