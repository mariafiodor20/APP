
typedef struct Node 
{ 
  char val[32]; 
  struct Node *next; 
} Node; 
