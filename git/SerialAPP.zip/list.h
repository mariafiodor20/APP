
typedef struct Node{
	struct Node* next;
	char val[32];
} Node;
