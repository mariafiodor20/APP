#!/bin/bash

./encryption -k key.key log 2
