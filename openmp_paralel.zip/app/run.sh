#!/bin/bash

./encryption -k key.key fisier_foarte_mare
./encryption -k key.key 64MBFile
./encryption -k key.key 128MBFile 
