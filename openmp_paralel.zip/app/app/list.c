#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"

void add(Node *head, char *val) {
    Node *current = head;

    if (current == NULL) {
    	current = malloc(sizeof(Node));
    	strcpy(current->val, val);

    	return;
    }

    while (current->next != NULL) {
        current = current->next;
    }

    current->next = malloc(sizeof(Node));
    strcpy(current->next->val, val);
    current->next->next = NULL;
}

void print (Node *head) {
	while (head != NULL) {
		printf("%s\n", head->val);
		head = head->next;
	}
}