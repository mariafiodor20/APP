#!/bin/bash

./encryption -k key.key fisier_mare 4
