#include "queue.h"

#define BLOCK_SIZE 32


static int nr_chunks = 0;
static char *all_data;
static gcry_cipher_hd_t handler;

int queue_terminate_workers(struct queue_struct *queue);
void check_error(int code, char *generator);
void queue_wait_workers(struct queue_struct *queue, int nthreads);
void process_tasks();
int get_work(struct q_work_struct* w);
void boss();
void worker();